Rails.application.routes.draw do
  devise_for :users #allows users to log in
  resources :pics do 
  	resources :usercomments, only: [:create, :index, :destroy]
  	member do
  		put "like", to: "pics#upvote" #like does pics#upvote function
  	end
  end
  root "pics#index" #root of webpage is index page
  mount Commontator::Engine => '/commontator' #initializes commontator gem
end
