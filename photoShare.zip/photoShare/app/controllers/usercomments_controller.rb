class CommentsController < ApplicationController
  before_action :authenticate_user!, except: [:index]
  before_action :find_article!

  def index #displays all comments for a pic in order to creation
  	@comments = @pic.usercomments.order(created_at: :desc)
  end

  def create #creates comments and saves them to database
  	@comment = @pic.usercomments.build(comment_params)
    @comment.user = current_user
    redirect to pic_path(@pic)
  end


  private
  def comment_params #defines usercomments
	params.require(:usercomment).permit(:body)
  end
  def find_pic!
    @pic = Pic.find(params[:pic_id])
  end
end