# some code sourced from coding rails online tutorial

class PicsController < ApplicationController

	def index
		@pics = Pic.all.order("created_at DESC") #the main page and shows all photos
	end

	def show
		@pic = Pic.find(params[:id]) #directs to show view in pics folder
	end

	def new
		@pic = current_user.pics.build #directs to new view in pics folder
	end

	def create
		@pic = current_user.pics.build(pic_params) 

		if @pic.save
			redirect_to @pic, notice: "Picture successfully posted"
		else
			render 'new'
		end
	end

	def edit
		@pic = Pic.find(params[:id]) #directs to edit view in pics folder
	end

	def update #updates photos in the database
		@pic = Pic.find(params[:id])
		if @pic.update(pic_params)
			redirect_to @pic, notice: "Succesfully updated"
		else
			render 'edit'
		end
	end

	def destroy #destroys photos in the database
		@pic = Pic.find(params[:id])
		@pic.destroy
		redirect_to root_path
	end

	def upvote #displays upvotes in the database
		@pic = Pic.find(params[:id])
		@pic.upvote_by current_user
		redirect_back fallback_location: root_path
	end

	private 

	def pic_params
		params.require(:pic).permit(:title, :description, :image)
	end

	def find_pic
		@pic = Pic.find(params[:id])
	end

end
