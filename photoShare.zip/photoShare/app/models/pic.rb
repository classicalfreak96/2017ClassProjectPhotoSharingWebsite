class Pic < ApplicationRecord
	acts_as_votable
	acts_as_commontable
	belongs_to :user #a pic belongs to a single user
	has_many :usercomments, dependent: :destroy #a pic has many comments
	has_attached_file :image, styles: { medium: "300x300>", thumb: "100x100>", large: "500x500>"}, default_url: "/images/:style/missing.png"
  validates_attachment_content_type :image, content_type: /\Aimage\/.*\z/
end
