class User < ApplicationRecord
	has_many :pics #a user has many pics
	acts_as_commontator #commontator gem allows user to comment
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable
end
