class Album < ActiveRecord::Base
  attr_accessible :title 
  has_many :pic #many photos belong in an album
end