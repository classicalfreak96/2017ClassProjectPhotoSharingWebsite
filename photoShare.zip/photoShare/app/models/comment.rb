class Comment < ApplicationRecord
  belongs_to :pic #pic has many comments
  validates :body, presence: true, allow_blank: false
end
