require 'test_helper'

class PicTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
